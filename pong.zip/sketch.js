let xBolinha = 300;
let yBolinha = 200;
let diametro = 20;
let raio = diametro /2;
let veloXBolinha = 6;
let veloYBolinha = 6;

let xRq = 5;
let yRq = 150;
let rqcompri = 10;
let rqaltura = 60;

let yraqueteoponente = 150;
let xraqueteoponente = 585;
let veloYOponente;

let meusPontos = 0;
let pontosOponente = 0;

let raquetesom;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3")
  ponto = loadSound("ponto.mp3")
  raquetesom = loadSound("raquetada.mp3")
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  circle(xBolinha, yBolinha, diametro);
  xBolinha += veloXBolinha
  yBolinha -= veloYBolinha
  rect(xRq, yRq, rqcompri, rqaltura)
  rect(xraqueteoponente, yraqueteoponente, rqcompri, rqaltura)
  movimentaMinhaRaquete();
  verificaColisaoRaquete();
  movimentaRaqueteOponente();
  verificaColisaoRaqueteOponente();
  incluiplacar();
  marcaponto();
  bolinhaNaoFicaPresa();

 if (xBolinha + raio > width || xBolinha -raio < 0){
    veloXBolinha *= -1}
  if (yBolinha + raio > height || yBolinha -raio < 0){veloYBolinha *= -1}
  
  function movimentaMinhaRaquete() {
    if (keyIsDown(UP_ARROW)) {
        yRq -= 10;
    }
    if (keyIsDown(DOWN_ARROW)) {
        yRq += 10;
    }
} 
function verificaColisaoRaquete() {
    if (xBolinha - raio < xRq + rqcompri
&& yBolinha - raio < yRq + rqaltura && yBolinha + raio > yRq) {
        veloXBolinha *= -1;
      raquetesom.play();
    }
  } 
function verificaColisaoRaqueteOponente() {
    if (xBolinha - raio > xraqueteoponente - rqcompri
&& yBolinha + raio > yraqueteoponente - rqaltura && yBolinha + raio > yraqueteoponente) {
        veloXBolinha *= -1;
      raquetesom.play();
    }
  } 
  
function movimentaRaqueteOponente(){
   if (keyIsDown(87)) {
        yraqueteoponente -= 10;
    }
    if (keyIsDown(83)) {
        yraqueteoponente += 10;
    }
}

function incluiplacar(){
  stroke(255);
  textAlign(CENTER)
  textSize(18);
  fill(color(255, 140, 0));
  rect(130, 10, 40, 20);
  fill(255);
  text(meusPontos, 150, 26);
  fill(color(255, 140, 0));
  rect(430, 10, 40, 20);
  fill(255);
  text(pontosOponente, 450, 26);
}
  function marcaponto(){
    if (xBolinha > 590){
      meusPontos += 1;
      ponto.play();
    }
    if (xBolinha < 10){
      pontosOponente += 1;
      ponto.play();
    }
  }
function bolinhaNaoFicaPresa(){
    if (xBolinha - raio < 0){
    xBolinha = 6
    }
  if (xBolinha - raio > 584){
    xBolinha = 560
  }
}

}